#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2019 Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

import unittest
import threading
import time
from contextlib import contextmanager

from pyspark.databricks.iter_utils import prefetch_iterator
from pyspark.databricks.testing.utils import wait_until


class PrefetchIteratorTest(unittest.TestCase):

    @contextmanager
    def assert_thread_count(self):
        cnt = threading.active_count()
        try:
            yield
        finally:
            wait_until(lambda: threading.active_count() == cnt, 1, 0.01)

    def generator(self):
        for i in range(10):
            yield i

    def iterator_counter(self, iterator):
        cnt = [0]

        def generator():
            for i in iterator:
                cnt[0] += 1
                yield i

        return generator(), lambda: cnt[0]

    def test_prefetch(self):
        with self.assert_thread_count():
            generator, counter = self.iterator_counter(self.generator())
            with prefetch_iterator(generator, 5) as it:
                wait_until(lambda: counter() == 5, 1, 0.01)
                for i in range(5):
                    self.assertEqual(i, next(it))
                wait_until(lambda: counter() == 10, 1, 0.01)
                self.assertRaises(StopIteration, lambda: next(generator))
                for i in range(5):
                    self.assertEqual(i + 5, next(it))
                self.assertRaises(StopIteration, lambda: next(it))

    def test_raise_exception_from_consumer(self):

        def raise_exception():
            with prefetch_iterator(self.generator(), 1) as it:
                for i in range(5):
                    next(it)
                raise RuntimeError()

        with self.assert_thread_count():
            self.assertRaises(RuntimeError, raise_exception)

    def test_raise_exception_from_iterator(self):

        def raising_iterator():
            for i in range(5):
                yield i
            raise RuntimeError()

        def raise_exception():
            with prefetch_iterator(raising_iterator(), 1) as it:
                for i in range(5):
                    next(it)
                next(it)

        with self.assert_thread_count():
                self.assertRaises(RuntimeError, raise_exception)

    def test_invalid_max_prefetch(self):

        def invalid_max_prefetch():
            with prefetch_iterator(self.generator(), 0) as i:
                pass

        with self.assert_thread_count():
            self.assertRaisesRegexp(
                AssertionError,
                "The number of prefetch needs to be a positive integer",
                invalid_max_prefetch)


if __name__ == "__main__":
    from pyspark.databricks.tests.test_iter_utils import *
    try:
        import xmlrunner
        unittest.main(testRunner=xmlrunner.XMLTestRunner(output='target/test-reports'), verbosity=2)
    except ImportError:
        unittest.main(verbosity=2)
