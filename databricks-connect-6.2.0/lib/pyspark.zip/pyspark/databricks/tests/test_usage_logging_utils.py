#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2019 Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

import unittest

from pyspark.databricks.testing.utils import UsageLoggingTestCase


class PythonUsageLoggingTest(UsageLoggingTestCase):
    """
    Test suite for Python wrapper for Databricks usage logging.
    """

    def test_basic_usage_logging(self):
        logger = self._usage_logging

        def function_with_logging():
            logger.recordEvent(
                logger.metricDefinitions().EVENT_ML_ALGORITHM(),
                {
                    logger.tagDefinitions().TAG_ML_RUN_UUID(): 'fakeTagEntry'
                },
                "my big blob"
            )
        usage_records = self.track_usage(function_with_logging)
        self.assertEqual(len(usage_records), 1,
                         "Expected 1 usage record but found {n}.".format(n=len(usage_records)))
        self.assert_tag(usage_records[0], logger.tagDefinitions().TAG_ML_RUN_UUID(),
                        'fakeTagEntry')


if __name__ == "__main__":
    from pyspark.databricks.tests.test_usage_logging_utils import *
    try:
        import xmlrunner
        unittest.main(testRunner=xmlrunner.XMLTestRunner(output='target/test-reports'), verbosity=2)
    except ImportError:
        unittest.main(verbosity=2)
